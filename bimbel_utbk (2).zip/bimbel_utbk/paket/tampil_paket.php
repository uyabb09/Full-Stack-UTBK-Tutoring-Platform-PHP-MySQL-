<?php
session_start();
include '../config/koneksi.php';

// Pastikan user login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

// Query asli Anda (saat ini tidak terpakai di HTML, tapi kita biarkan)
$query = "SELECT * FROM paket_bimbel";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Paket Bimbel</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- WAJIB ADA untuk ikon panah kembali -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --secondary-color: #FFB700;
        }
        body {
            /* Menggunakan font Poppins dari style asli Anda */
            font-family: 'Poppins', sans-serif; 
            
            /* === PERUBAHAN BACKGROUND (GRADASI + MOTIF) === */
            
            /* Gradasi Ungu/Pink Halus (gak norak) */
            background-color: #a18cd1; /* Warna fallback jika gradasi gagal */
            
            /* Layer 1: Motif Garis Diagonal Halus (Transparan)
              Layer 2: Gradasi Warna Utama 
            */
            background-image: 
                repeating-linear-gradient(
                    -45deg, 
                    rgba(255,255,255,0.05), 
                    rgba(255,255,255,0.05) 10px, 
                    transparent 10px, 
                    transparent 20px
                ),
                linear-gradient(135deg, #fbc2eb 0%, #a18cd1 100%);
            
            /* === AKHIR PERUBAHAN === */
        }
        .section {
            padding: 70px 0;
            text-align: center;
        }
        .card {
            border: none;
            border-radius: 20px;
            color: #fff;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.25);
        }
        .price {
            font-size: 32px;
            font-weight: 700;
            margin: 20px 0;
        }
        .btn-pilih {
            background: rgba(255,255,255,0.9);
            color: #222;
            font-weight: 600;
            border-radius: 12px;
            padding: 10px 25px;
            border: none;
            transition: 0.3s;
        }
        .btn-pilih:hover {
            background: #fff;
            color: #000;
        }
        .card.basic { background: linear-gradient(135deg, #6dd5ed, #2193b0); }
        .card.standard { background: linear-gradient(135deg, #f7971e, #ffd200); }
        .card.premium { background: linear-gradient(135deg, #8e2de2, #4a00e0); }
        ul {
            list-style: none;
            padding: 0;
            text-align: left;
            color: rgba(255,255,255,0.9);
        }
        ul li::before {
            content: "✓";
            margin-right: 8px;
            color: #fff;
        }
        /* Tombol riwayat dan logout */
        .header-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }
    </style>
</head>
<body>

<section class="section">
    <div class="container">

<div class="header-nav mb-4 d-flex justify-content-between align-items-center">
    <!-- INI YANG DIPERBAIKI: Menggunakan 'nama_user' (sesuai session login) -->
    <h5 class="mb-0 text-dark">Halo, <b><?= htmlspecialchars($_SESSION['nama_user'] ?? 'Pengguna'); ?></b>!</h5>

    <div>
        <a href="../user_home.php" class="btn btn-outline-secondary btn-sm shadow-sm me-2">
            <i class="bi bi-arrow-left"></i> Kembali ke Home
        </a>
        <a href="../transaksi/tampil_transaksi.php" class="btn btn-warning btn-sm shadow-sm">
            🔄 Riwayat Transaksi
        </a>
        <a href="../user/logout.php" class="btn btn-danger btn-sm shadow-sm ms-2">
            Logout
        </a>
    </div>
</div>
    
        <h2 class="fw-bold mb-4 text-dark" data-aos="fade-up">Pilih Paket Bimbel Kamu</h2>
        <p class="text-muted mb-5" data-aos="fade-up" data-aos-delay="100">Belajar lebih mudah dan efektif sesuai kebutuhanmu ✨</p>
        
        <div class="row justify-content-center g-4">
            
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card basic p-4">
                    <h4 class="fw-bold">Paket Basic</h4>
                    <div class="price">Rp. 500.000</div>
                    <ul>
                        <li>3 Video Pembelajaran (7 menit)</li>
                        <li>5 Pelatihan Soal</li>
                        <li>2 Buku Pembelajaran</li>
                    </ul>
                    <a href="../pembayaran/tambah_pembayaran.php?paket_id=PK001" class="btn btn-pilih">Pilih Paket</a>
                </div>
            </div>

            <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                <div class="card standard p-4">
                    <h4 class="fw-bold">Paket Standart</h4>
                    <div class="price">Rp. 800.000</div>
                    <ul>
                        <li>6 Video Pembelajaran (12 menit)</li>
                        <li>12 Pelatihan Soal</li>
                        <li>4 Buku Pembelajaran</li>
                        <li>1 Pertemuan Dengan Pembimbing</li>
                    </ul>
                    <a href="../pembayaran/tambah_pembayaran.php?paket_id=PK002" class="btn btn-pilih mt-3">Pilih Paket</a>
                </div>
            </div>

            <div class="col-md-4" data-aos="fade-up" data-aos-delay="400">
                <div class="card premium p-4">
                    <h4 class="fw-bold">Paket Premium</h4>
                    <div class="price">Rp. 1.200.000</div>
                    <ul>
                        <li>15 Video Pembelajaran (18 menit)</li>
                        <li>25 Pelatihan Soal</li>
                        <li>12 Buku Pembelajaran</li>
                        <li>5 Pertemuan Dengan Pembimbing</li>
                        <li>Bonus Sertifikat Resmi Bimbel</li>
                    </ul>
                    <a href="../pembayaran/tambah_pembayaran.php?paket_id=PK003" class="btn btn-pilih mt-3">Pilih Paket</a>
                </div>
            </div>

        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    AOS.init({
        duration: 700, // Durasi animasi
        once: true // Animasi hanya sekali
    });
</script>

<?php
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    echo "
    <script>
        Swal.fire({
            icon: '" . $message['type'] . "',
            title: '" . $message['title'] . "',
            text: '" . $message['text'] . "',
            timer: 2500, // Tutup otomatis
            showConfirmButton: false,
            toast: true, // Tampilkan sebagai toast kecil
            position: 'top-end' // di pojok kanan atas
        });
    </script>
    ";
    // Hapus pesan setelah ditampilkan
    unset($_SESSION['flash_message']);
}
?>

</body>
</html>