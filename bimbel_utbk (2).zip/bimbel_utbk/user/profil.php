<?php
session_start();
include '../config/koneksi.php';

// 1. Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='login.php';</script>";
    exit();
}

// 2. Ambil data user dari database
$user_id = $_SESSION['user_id'];
// Mengambil semua kolom dari tabel user berdasarkan user_id
$query_profil = "SELECT * FROM user WHERE user_id = '$user_id'";
$result_profil = mysqli_query($koneksi, $query_profil);

if (mysqli_num_rows($result_profil) > 0) {
    $data_user = mysqli_fetch_assoc($result_profil);
} else {
    echo "Data user tidak ditemukan.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - Bimbel UTBK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="../user_home.php">
                Bimbel<span class="text-accent">UTBK</span>
            </a>
            <div class="ms-auto">
                <a href="../user_home.php" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-arrow-left"></i> Kembali ke Home
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-5">
                        <h3 class="fw-bold mb-4 text-center">Profil Saya</h3>

                        <div class="text-center mb-4">
                            <img src="https://placehold.co/100x100/E9ECEF/333?text=<?= strtoupper(substr($data_user['nama'], 0, 1)); ?>" class="rounded-circle img-thumbnail" alt="Foto Profil" width="100" height="100">
                        </div>

                        <div class="mb-3">
                            <label class="form-label text-muted small">Nama Lengkap</label>
                            <p class="fw-bold fs-5"><?= htmlspecialchars($data_user['nama']); ?></p>
                        </div>
                        <hr>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label text-muted small">Email</label>
                                <p class="fw-bold"><?= htmlspecialchars($data_user['email']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted small">Nomor Telepon</label>
                                <p class="fw-bold"><?= htmlspecialchars($data_user['no_telp'] ?? '-'); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="mb-4">
                            <label class="form-label text-muted small">Alamat</label>
                            <p class="fw-bold"><?= htmlspecialchars($data_user['alamat'] ?? '-'); ?></p>
                        </div>
                        <div class="mb-4">
                            <label class="form-label text-muted small">Bergabung Sejak</label>
                            <p class="fw-bold"><?= date('d F Y', strtotime($data_user['tanggal_daftar'])); ?></p>
                        </div>

                        <div class="d-grid gap-2 mt-5">
                            <a href="logout.php" class="btn btn-danger">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>