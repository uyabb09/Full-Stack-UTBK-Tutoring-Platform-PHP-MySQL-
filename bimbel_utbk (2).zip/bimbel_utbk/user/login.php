<?php
// Bagian atas tetap sama untuk memproses login
session_start();
include '../config/koneksi.php';

// Jika user sudah login, langsung arahkan ke home
if (isset($_SESSION['user_id'])) {
    header("Location: ../user_home.php");
    exit();
}

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    // Ambil password mentah, jangan di-escape
    $password = $_POST['password'];

    // --- PERUBAHAN LOGIKA LOGIN DIMULAI DI SINI ---

    // 1. Ambil data HANYA berdasarkan email
    $query = mysqli_query($koneksi, "SELECT * FROM user WHERE email='$email'");

    // 2. Cek apakah emailnya ada
    if (mysqli_num_rows($query) === 1) {
        $data = mysqli_fetch_assoc($query);

        // 3. Verifikasi password yang di-hash di database
        if (password_verify($password, $data['password'])) {
            // --- LOGIN BERHASIL ---
            // Password yang kamu masukkan COCOK dengan hash di database
            
            $_SESSION['user_id'] = $data['user_id'];
            $_SESSION['nama_user'] = $data['nama']; // Kunci session harus 'nama_user'
            $_SESSION['email'] = $data['email'];
            
            echo "<script>alert('Login berhasil! Selamat datang, " . htmlspecialchars($data['nama']) . "'); window.location='../user_home.php';</script>";
            exit;

        } else {
            // Password tidak cocok
            $error_msg = "Email atau password salah!";
        }

    } else {
        // Email tidak ditemukan
        $error_msg = "Email atau password salah!";
    }
    // --- AKHIR PERUBAHAN LOGIKA ---
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login User - Bimbel UTBK</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- BARU: Link untuk Ikon Mata (Bootstrap Icons) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #0d6efd; 
            --text-dark: #2d3748;
        }

        body {
            font-family: 'Inter', sans-serif;
            
            /* === BACKGROUND SAMA SEPERTI TAMPIL_PAKET.PHP === */
            background-color: #a18cd1; /* Fallback */
            background-image: 
                repeating-linear-gradient(
                    -45deg, 
                    rgba(255,255,255,0.05), 
                    rgba(255,255,255,0.05) 10px, 
                    transparent 10px, 
                    transparent 20px
                ),
                linear-gradient(135deg, #fbc2eb 0%, #a18cd1 100%);
            /* === AKHIR BACKGROUND === */

            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 2rem 0;
        }

        .card-login { 
            width: 100%; 
            max-width: 400px; 
            border: none; 
            border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
            background-color: #ffffff;
        }
        
        /* Style untuk input dan tombol */
        .form-control {
            padding: 0.75rem 1rem;
            border: 1px solid #ddd;
            border-radius: 0; /* Hapus radius di sini */
        }
        
        .form-control:not(.input-group .form-control) {
            border-radius: 10px; /* Terapkan radius 10px di sini */
        }
        
        .input-group {
            border-radius: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
            overflow: hidden; 
        }
        .input-group .form-control { border: none; }
        .input-group .input-group-text { border: none; background-color: #fff; cursor: pointer; }
        
        .input-group:focus-within,
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
        }

        .btn-primary { 
            background-color: var(--primary-color); 
            border: none; 
            padding: 12px; 
            font-weight: 600; 
            border-radius: 10px; /* Samakan radiusnya */
        }
        .btn-primary:hover { background-color: #0b5ed7; }
        .link-daftar {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="card card-login p-4">
        <div class="card-body">
            <!-- Judul diperjelas -->
            <h3 class="text-center fw-bold mb-4">Login User</h3>

            <?php if (isset($error_msg)): ?>
                <div class="alert alert-danger py-2 text-center" role="alert">
                    <?= $error_msg; ?>
                </div>
            <?php endif; ?>

            <!-- Notifikasi flash message (jika ada dari halaman daftar) -->
            <?php
            if (isset($_SESSION['flash_message'])) {
                $msg = $_SESSION['flash_message'];
                echo "<div class='alert alert-{$msg['type']} py-2 text-center' role='alert'>{$msg['text']}</div>";
                unset($_SESSION['flash_message']); // Hapus setelah ditampilkan
            }
            ?>

            <form action="login.php" method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label fw-semibold">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required placeholder="contoh@email.com">
                </div>
                
                <!-- KOLOM PASSWORD DENGAN IKON MATA -->
                <div class="mb-4">
                    <label for="password" class="form-label fw-semibold">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="passwordInput" name="password" required placeholder="********">
                        <span class="input-group-text" id="togglePassword">
                            <i class="bi bi-eye-slash-fill"></i>
                        </span>
                    </div>
                </div>
                <!-- AKHIR KOLOM PASSWORD -->

                <button type="submit" name="login" class="btn btn-primary w-100 mb-3">Masuk Sekarang</button>
            </form>

            <div class="text-center">
                <p class="text-muted mb-0">Belum punya akun? <a href="daftar.php" class="link-daftar">Daftar disini</a></p>
                <p class="mt-2"><a href="../index.php" class="text-muted text-decoration-none small"> Kembali ke Menu Awal</a></p>
            </div>
        </div>
    </div>

<!-- Script untuk Toggle Password -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('passwordInput');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function () {
                const icon = this.querySelector('i');
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                if (type === 'password') {
                    icon.classList.remove('bi-eye-fill');
                    icon.classList.add('bi-eye-slash-fill');
                } else {
                    icon.classList.remove('bi-eye-slash-fill');
                    icon.classList.add('bi-eye-fill');
                }
            });
        }
    });
</script>
</body>
</html>