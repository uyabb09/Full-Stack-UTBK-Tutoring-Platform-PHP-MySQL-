<?php
include '../config/koneksi.php';
session_start(); // Mulai session untuk flash message

$error_message = '';

if (isset($_POST['daftar'])) {
    // Gunakan uniqid dari file asli Anda
    $user_id = uniqid('U'); 
    
    // Ambil semua data dan bersihkan
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $no_telp = mysqli_real_escape_string($koneksi, $_POST['no_telp']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $tanggal_daftar = date('Y-m-d');
    
    // --- PENINGKATAN KEAMANAN ---
    // Hash password menggunakan BCRYPT (sesuai file buat_hash_sementara.php)
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Cek duplikasi email
    $cek_email = mysqli_query($koneksi, "SELECT email FROM user WHERE email='$email'");
    if (mysqli_num_rows($cek_email) > 0) {
        $error_message = "Email ini sudah terdaftar. Silakan gunakan email lain.";
    } else {
        // --- Query Asli Anda ---
        $query = "INSERT INTO user (user_id, nama, email, password, no_telp, alamat, tanggal_daftar)
        VALUES ('$user_id', '$nama', '$email', '$password', '$no_telp', '$alamat', '$tanggal_daftar')";
        
        $simpan = mysqli_query($koneksi, $query);

        if ($simpan) {
            // --- INTERAKTIF ---
            // Buat notifikasi untuk ditampilkan di halaman login
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'title' => 'Pendaftaran Berhasil!',
                'text' => 'Akun Anda telah dibuat. Silakan login.'
            ];
            header("Location: login.php");
            exit;
        } else {
            $error_message = "Gagal mendaftar. Terjadi kesalahan pada server.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun | Bimbel UTBK</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- BARU: Link CSS untuk Bootstrap Icons (Ikon Mata) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --secondary-color: #FFB700;
            --background-light: #f9fafb;
            --text-dark: #2d3748;
            --text-light: #718096;
            --success-color: #059669; /* Warna hijau untuk tombol daftar */
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 2rem 0;
        }

        .register-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .register-card .card-body {
            padding: 2.5rem;
        }

        .register-header {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }
        
        .register-subheader {
            color: var(--text-light);
            font-weight: 400;
            margin-bottom: 2rem;
        }

        /* --- PERBAIKAN CSS FORM --- */
        
        /* Hapus border-radius dari .form-control */
        .form-control {
            padding: 0.75rem 1rem;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
            border-radius: 0; /* Hapus radius di sini */
        }
        
        /* Terapkan border-radius ke wrapper-nya, KECUALI input-group */
        .form-control:not(.input-group .form-control),
        .form-select,
        textarea.form-control {
            border-radius: 10px; /* Terapkan radius 10px di sini */
        }
        
        /* Atur radius untuk input-group (password) */
        .input-group {
            border-radius: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
            overflow: hidden; /* Kunci agar radius rapi */
        }
        .input-group .form-control {
            border: none; /* Hapus border internal */
        }
        .input-group .input-group-text {
            border: none; /* Hapus border internal */
            background-color: #fff;
            cursor: pointer;
        }
        
        /* Atur style focus untuk group */
        .input-group:focus-within,
        .form-control:focus,
        .form-select:focus,
        textarea.form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(0, 82, 212, 0.1);
        }
        
        /* --- AKHIR PERBAIKAN CSS FORM --- */

        .btn-success {
            background-color: var(--success-color);
            border: none;
            border-radius: 10px;
            padding: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-success:hover {
            background-color: #047857;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(5, 150, 105, 0.2);
        }

        .link-login {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6" data-aos="zoom-in" data-aos-duration="600">
            <div class="card register-card">
                <div class="card-body">
                    <h2 class="register-header text-center">Buat Akun Baru</h2>
                    <p class="register-subheader text-center">Isi data lengkap untuk mendaftar</p>

                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Nama Lengkap</label>
                                <input type="text" name="nama" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                        </div>

                        <!-- =============================== -->
                        <!--     PERUBAHAN KOLOM PASSWORD    -->
                        <!-- =============================== -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Password</label>
                            <div class="input-group">
                                <input type="password" name="password" id="passwordInput" class="form-control" required>
                                <!-- Tombol Ikon Mata -->
                                <span class="input-group-text" id="togglePassword">
                                    <i class="bi bi-eye-slash-fill"></i>
                                </span>
                            </div>
                        </div>
                        <!-- =============================== -->
                        <!--      AKHIR PERUBAHAN PASSWORD   -->
                        <!-- =============================== -->


                        <div class="mb-3">
                            <label class="form-label fw-semibold">No. Telepon</label>
                            <input type="text" name="no_telp" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Alamat</label>
                            <textarea name="alamat" class="form-control" rows="2" required></textarea>
                        </div>

                        <button type="submit" name="daftar" class="btn btn-success w-100 mt-3">Daftar Sekarang</button>
                        
                        <p class="text-center text-muted mt-4 mb-0">
                            Sudah punya akun? <a href="login.php" class="link-login">Login di sini</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<!-- =============================== -->
<!-- BARU: SCRIPT UNTUK TOGGLE PASSWORD -->
<!-- =============================== -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('passwordInput');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function () {
                const icon = this.querySelector('i');
                
                // Cek tipe input saat ini
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                // Ganti ikon
                if (type === 'password') {
                    // Jika password disembunyikan
                    icon.classList.remove('bi-eye-fill');
                    icon.classList.add('bi-eye-slash-fill');
                } else {
                    // Jika password ditampilkan
                    icon.classList.remove('bi-eye-slash-fill');
                    icon.classList.add('bi-eye-fill');
                }
            });
        }
    });
</script>
<!-- =============================== -->

<script>
    AOS.init();
</script>

<?php if (!empty($error_message)): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Pendaftaran Gagal',
        text: '<?= $error_message ?>',
        confirmButtonColor: '#0052D4'
    });
</script>
<?php endif; ?>

</body>
</html>