<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

// Ambil data paket berdasarkan ID
if (isset($_GET['paket_id'])) {
    $paket_id = $_GET['paket_id'];
    $query = mysqli_query($koneksi, "SELECT * FROM paket_bimbel WHERE paket_id = '$paket_id'");
    $paket = mysqli_fetch_assoc($query);
}

if (isset($_POST['konfirmasi'])) {
    $id_user = $_SESSION['user_id'];
    $paket_id = $_POST['paket_id'];
    $tgl = date('Y-m-d');
    $status = 'Menunggu Verifikasi';

    // Simpan transaksi
    $insert = mysqli_query($koneksi, "INSERT INTO transaksi (id_user, paket_id, tanggal_transaksi, status) VALUES ('$id_user', '$paket_id', '$tgl', '$status')");

    if ($insert) {
        echo "<script>alert('Pembayaran berhasil dikirim. Menunggu verifikasi admin.'); window.location='../transaksi/tampil_transaksi.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan transaksi.');</script>";
    }
}
?>

<h2>Konfirmasi Pembayaran</h2>
<?php if (!empty($paket)) { ?>
<form method="POST">
    <input type="hidden" name="paket_id" value="<?= $paket['paket_id'] ?>">
    <p>Nama Paket: <b><?= $paket['nama_paket'] ?></b></p>
    <p>Kategori: <?= $paket['kategori'] ?></p>
    <p>Durasi: <?= $paket['durasi'] ?></p>
    <p>Harga: Rp <?= number_format($paket['harga'], 0, ',', '.') ?></p>

    <button type="submit" name="konfirmasi">Konfirmasi & Bayar</button>
</form>
<?php } else { ?>
    <p>Paket tidak ditemukan!</p>
<?php } ?>
