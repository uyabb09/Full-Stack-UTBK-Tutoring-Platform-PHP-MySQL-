<?php
session_start();
include '../config/koneksi.php';

$error_message = '';

// Cek koneksi database
if (!isset($koneksi) || !$koneksi) {
    $error_message = "Koneksi database gagal.";
}

// Cek login user
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
// Ambil paket_id dari URL
$paket_id = $_GET['paket_id'] ?? null;

if (!$paket_id) {
    $error_message = "Paket tidak ditemukan. Silakan pilih paket kembali.";
}

// Jika tidak ada error awal, ambil data paket
if (empty($error_message)) {
    $paket_id_esc = mysqli_real_escape_string($koneksi, $paket_id);
    $q = mysqli_query($koneksi, "SELECT * FROM paket_bimbel WHERE paket_id = '$paket_id_esc' LIMIT 1");
    if (!$q || mysqli_num_rows($q) == 0) {
        $error_message = "Paket tidak valid. Silakan pilih paket kembali.";
    } else {
        $paket = mysqli_fetch_assoc($q);
    }
}

// Proses jika tombol upload ditekan
if (isset($_POST['upload']) && empty($error_message)) {
    $metode = mysqli_real_escape_string($koneksi, $_POST['metode'] ?? '');
    $harga = $paket['harga'];
    $tanggal = date('Y-m-d H:i:s'); // Menggunakan DATETIME

    // Cek apakah file ada
    if (!empty($_FILES['bukti']['name'])) {
        $nama_file = time() . "_" . preg_replace('/[^A-Za-z0-9_.-]/', '_', basename($_FILES['bukti']['name']));
        $tmp = $_FILES['bukti']['tmp_name'];
        // Folder tujuan upload (pastikan folder ini ada dan writeable)
        $folder = __DIR__ . "/../uploads/";
        
        // Buat folder jika belum ada
        if (!is_dir($folder)) {
            if (!mkdir($folder, 0755, true)) {
                $error_message = "Gagal membuat folder uploads. Periksa permission server.";
            }
        }
        
        if (empty($error_message)) {
            $target = $folder . $nama_file;

            // Pindahkan file yang diupload
            if (move_uploaded_file($tmp, $target)) {
                
                // Fungsi helper untuk generate ID acak
                function generateRandomID($prefix, $length = 8) {
                    $random_length = $length - strlen($prefix);
                    if ($random_length < 1) $random_length = 1; 
                    $bytes = random_bytes(ceil($random_length / 2));
                    $random_hex = substr(bin2hex($bytes), 0, $random_length);
                    return $prefix . strtoupper($random_hex);
                }

                // 1. Buat Transaksi Baru
                $transaksi_id = generateRandomID('TRX', 8);
                $ins_trx = mysqli_query($koneksi, "
                    INSERT INTO transaksi (transaksi_id, tanggal_transaksi, status_transaksi, total_bayar, user_id, paket_id)
                    VALUES ('$transaksi_id', '$tanggal', 'Menunggu Pembayaran', '$harga', '$user_id', '$paket_id_esc')
                ");

                if (!$ins_trx) {
                    // Jika gagal buat transaksi, hapus file yang sudah terupload
                    @unlink($target);
                    $error_message = "Gagal membuat transaksi: " . mysqli_error($koneksi);
                } else {
                    // 2. Buat Data Pembayaran
                    $pembayaran_id = generateRandomID('PAY', 8);
                    $nama_file_esc = mysqli_real_escape_string($koneksi, $nama_file);
                    
                    $ins_pay = mysqli_query($koneksi, "
                        INSERT INTO pembayaran (pembayaran_id, transaksi_id, metode, nominal, bukti_bayar, tanggal_bayar, status_validasi)
                        VALUES ('$pembayaran_id', '$transaksi_id', '$metode', '$harga', '$nama_file_esc', '$tanggal', 'Menunggu Validasi')
                    ");

                    if (!$ins_pay) {
                        // Jika gagal simpan pembayaran, rollback transaksi & hapus file
                        mysqli_query($koneksi, "DELETE FROM transaksi WHERE transaksi_id = '$transaksi_id'");
                        @unlink($target);
                        $error_message = "Gagal menyimpan pembayaran: " . mysqli_error($koneksi);
                    } else {
                        // BERHASIL SEMUA: Set flash message dan redirect
                        $_SESSION['flash_message'] = [
                            'type' => 'success',
                            'title' => 'Upload Berhasil!',
                            'text' => 'Bukti pembayaran Anda sedang divalidasi oleh admin.'
                        ];
                        header("Location: ../transaksi/tampil_transaksi.php");
                        exit;
                    }
                }

            } else {
                $error_message = "Upload file gagal. Pastikan folder uploads punya izin tulis (writeable).";
            }
        }
    } else {
        $error_message = "Silakan pilih file bukti transfer terlebih dahulu.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Upload Bukti Pembayaran</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --secondary-color: #FFB700;
            --text-dark: #2d3748;
            --text-light: #718096;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            /* Background Gradient Modern */
            background: linear-gradient(135deg, #30cfd0 0%, #330867 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 2rem 0;
        }

        .payment-card {
            background-color: #fff; /* Pastikan card punya background putih */
            border: none; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); /* Shadow sedikit lebih gelap agar kontras */
            overflow: hidden; 
            width: 100%; 
            max-width: 600px;
            margin: 0 auto;
        }
        .payment-card .card-body { 
            padding: 2.5rem; 
        }
        .card-header {
            background-color: transparent; /* Hapus background default bootstrap */
            border-bottom: none;
            font-size: 1.75rem; 
            font-weight: 700; 
            color: var(--text-dark);
            margin-bottom: 2rem; 
            text-align: center;
            padding-bottom: 0; /* Reset padding bawaan */
        }
        .paket-info {
            background-color: #f8faff; /* Warna background lebih terang dan bersih */
            border: 1px solid #e2e8f0; /* Border lebih halus */
            border-radius: 12px;
            padding: 1.5rem; 
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .paket-info h5 { 
            font-weight: 700; 
            color: var(--primary-color); 
            margin-bottom: 0.5rem;
        }
        .paket-info .harga { 
            font-size: 1.25rem; 
            font-weight: 700; 
            color: var(--text-dark); 
        }
        .form-control, .form-select {
            border-radius: 10px; 
            padding: 0.75rem 1rem; 
            border: 1px solid #ddd;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color); 
            box-shadow: 0 0 0 4px rgba(0, 82, 212, 0.1);
        }
        .form-label { 
            font-weight: 600; 
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }
        .btn-primary {
            background-color: var(--primary-color); 
            border: none; 
            border-radius: 10px;
            padding: 0.75rem; 
            font-weight: 700; 
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0041a8; 
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }
        .btn-link-batal { 
            color: var(--text-light); 
            text-decoration: none; 
            font-weight: 600;
            transition: color 0.3s ease;
        }
        .btn-link-batal:hover {
            color: var(--primary-color);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" data-aos="zoom-in" data-aos-duration="600">
            <div class="payment-card">
                <div class="card-body">
                    
                    <?php if (empty($error_message) && isset($paket)): ?>
                        <h2 class="card-header">Konfirmasi Pembayaran</h2>
                        
                        <div class="paket-info">
                            <h5><?= htmlspecialchars($paket['nama_paket']) ?></h5>
                            <p class="mb-3 text-muted"><?= htmlspecialchars($paket['deskripsi']) ?></p>
                            <div class="d-flex justify-content-between align-items-center border-top pt-3">
                                <span class="text-dark fw-semibold">Durasi: <?= htmlspecialchars($paket['durasi']) ?></span>
                                <span class="harga">Rp <?= number_format($paket['harga'],0,',','.') ?></span>
                            </div>
                        </div>

                        <form method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Pilih Metode Pembayaran</label>
                                
                                <!-- ============================================= -->
                                <!--           PERUBAHAN ADA DI SINI             -->
                                <!-- ============================================= -->
                                <select name="metode" class="form-select" required>
                                    <option value="" disabled selected>-- Pilih Bank/E-Wallet --</option>
                                    <option value="Mandiri">Mandiri - 111222333 (a.n. Bimbel UTBK)</option>
                                    <option value="BCA">BCA - 1234567890 (a.n. Bimbel UTBK)</option>
                                    <option value="BNI">BNI - 444555666 (a.n. Bimbel UTBK)</option>
                                    <option value="GoPay">GoPay - 081298765432 (a.n. Bimbel UTBK)</option>
                                    <option value="OVO">OVO - 081234567890 (a.n. Bimbel UTBK)</option>
                                    <option value="Dana">DANA - 081234567890 (a.n. Bimbel UTBK)</option>
                                </select>
                                <!-- ============================================= -->
                                <!--           AKHIR DARI PERUBAHAN              -->
                                <!-- ============================================= -->
                                
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Upload Bukti Transfer (jpg/png/pdf)</label>
                                <input type="file" name="bukti" accept=".jpg,.jpeg,.png,.pdf" class="form-control" required>
                                <div class="form-text">Pastikan foto bukti transfer terlihat jelas.</div>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" name="upload" class="btn btn-primary">Kirim Bukti & Buat Transaksi</button>
                                <div class="text-center mt-2">
                                    <a href="../paket/tampil_paket.php" class="btn-link-batal">Batal</a>
                                </div>
                            </div>
                        </form>
                    
                    <?php else: ?>
                        <!-- Tampilan Error -->
                        <h2 class="card-header text-danger">Terjadi Kesalahan</h2>
                        <div class="alert alert-danger text-center" role="alert">
                            <?= htmlspecialchars($error_message) ?>
                        </div>
                        <div class="text-center mt-4">
                            <a href="../paket/tampil_paket.php" class="btn btn-primary">Kembali ke Daftar Paket</a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    AOS.init();
</script>

<?php if (!empty($error_message) && isset($_POST['upload'])): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Upload Gagal',
        text: '<?= htmlspecialchars($error_message) ?>',
        confirmButtonColor: '#0052D4'
    });
</script>
<?php endif; ?>

</body>
</html>