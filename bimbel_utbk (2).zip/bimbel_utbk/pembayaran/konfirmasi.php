<?php
include '../config/koneksi.php';
$trx_id = $_GET['trx'] ?? '';

if (isset($_POST['bayar'])) {
    $pembayaran_id = uniqid('PAY');
    $metode = $_POST['metode'];
    $nominal = $_POST['nominal'];
    $bukti = $_POST['bukti']; // contoh: nama file
    $tanggal_bayar = date('Y-m-d H:i:s');
    $status = "Menunggu Validasi";

    $sql = "INSERT INTO pembayaran VALUES('$pembayaran_id','$trx_id','$metode','$nominal','$bukti','$tanggal_bayar','$status')";
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        echo "Pembayaran berhasil dikirim, menunggu validasi admin.";
    } else {
        echo "Gagal konfirmasi pembayaran: " . mysqli_error($koneksi);
    }
}
?>

<form method="POST">
    <input type="hidden" name="trx_id" value="<?= $trx_id ?>">
    <input type="text" name="metode" placeholder="Metode Pembayaran"><br>
    <input type="number" name="nominal" placeholder="Nominal"><br>
    <input type="text" name="bukti" placeholder="Nama File Bukti"><br>
    <button type="submit" name="bayar">Kirim</button>
</form>

