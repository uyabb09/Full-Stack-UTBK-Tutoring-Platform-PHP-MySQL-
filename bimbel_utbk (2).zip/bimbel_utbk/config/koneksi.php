<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "bimbel_utbk";

$koneksi = mysqli_connect("localhost", "root", "", "bimbel_utbk");

// tambahkan alias biar semua file bisa pakai $conn
$conn = $koneksi;

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

?>
