<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang - Bimbel UTBK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <link rel="stylesheet" href="style.css">

    <style>
        /* CSS Tambahan Langsung */
        .selection-page-body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            /* Pilihan Gradient 1: Biru Segar (Recommended) */
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            
            /* Pilihan Gradient 2: Ungu Modern (Kalau mau coba, hapus komentar di bawah ini) */
            /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
            
            /* Pilihan Gradient 3: Hangat/Senja */
            /* background: linear-gradient(120deg, #f6d365 0%, #fda085 100%); */
        }

        .selection-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2); /* Shadow lebih lembut tapi tegas */
            width: 100%;
            max-width: 420px; /* Sedikit lebih lebar agar lega */
            transition: transform 0.3s ease;
        }

        .selection-container:hover {
            transform: translateY(-5px); /* Efek naik sedikit saat di-hover */
        }

        .btn-lg {
            padding: 12px 20px;
            font-weight: 600;
            border-radius: 12px;
        }
    </style>
</head>
<body class="selection-page-body">

    <div class="selection-container" data-aos="zoom-in" data-aos-duration="800">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Bimbel UTBK</h3>
            <p class="text-muted">Gerbang menuju kampus impianmu ✨</p>
        </div>

        <p class="text-center mb-4 fw-semibold">Silakan lanjutkan sebagai:</p>
        
        <div class="d-grid gap-3">
            <a href="user_home.php" class="btn btn-primary btn-lg shadow-sm">
                👨‍🎓 Menu User
            </a>
            
            <a href="admin/login_admin.php" class="btn btn-outline-secondary btn-lg">
                🔐 Login Admin
            </a>
        </div>
    </div>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>