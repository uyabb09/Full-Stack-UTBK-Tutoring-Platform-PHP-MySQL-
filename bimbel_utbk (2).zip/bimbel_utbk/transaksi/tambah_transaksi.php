<?php
session_start();
include '../config/koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum, arahkan ke halaman login
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='../user/login.php';</script>";
    exit();
}

// Ambil data dari session dan URL
$user_id = $_SESSION['user_id'];
// Pastikan kita mengambil 'paket_id', bukan 'id_paket' agar konsisten
$paket_id = isset($_GET['paket_id']) ? $_GET['paket_id'] : '';

if (empty($paket_id)) {
    echo "Paket tidak valid. Silakan kembali pilih paket.";
    exit();
}

// 1. AMBIL HARGA PAKET DULU
// Kita perlu harga paket untuk mengisi kolom 'total_bayar' di tabel transaksi
$query_paket = mysqli_query($koneksi, "SELECT harga FROM paket_bimbel WHERE paket_id = '$paket_id'");
$data_paket = mysqli_fetch_assoc($query_paket);

if (!$data_paket) {
    echo "Data paket tidak ditemukan di database.";
    exit();
}

$total_bayar = $data_paket['harga'];

// 2. BUAT ID TRANSAKSI OTOMATIS (CHAR 8)
// Format: TR + 6 angka acak (contoh: TR123456)
$transaksi_id = 'TR' . rand(100000, 999999);
$tanggal_transaksi = date('Y-m-d H:i:s');

// 3. INSERT KE DATABASE TRANSAKSI
// Perhatikan nama kolomnya harus SAMA PERSIS dengan di database kamu!
$query_insert = "INSERT INTO transaksi (transaksi_id, tanggal_transaksi, status_transaksi, total_bayar, user_id, paket_id) 
                VALUES ('$transaksi_id', '$tanggal_transaksi', 'Menunggu Pembayaran', '$total_bayar', '$user_id', '$paket_id')";

if (mysqli_query($koneksi, $query_insert)) {
    // BERHASIL: Langsung arahkan ke halaman pembayaran dengan membawa ID Transaksi
    header("Location: ../pembayaran/tambah_pembayaran.php?id=$transaksi_id");
    exit();
} else {
    // GAGAL: Tampilkan pesan error untuk debugging
    echo "Gagal membuat transaksi: " . mysqli_error($koneksi);
}
?>