while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>{$row['id_transaksi']}</td>";
    echo "<td>{$row['nama_paket']}</td>";
    echo "<td>{$row['tanggal']}</td>";
    echo "<td>{$row['status']}</td>";
    echo "</tr>";
}
