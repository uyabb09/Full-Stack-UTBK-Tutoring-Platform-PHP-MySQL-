<?php
session_start();
include('../config/koneksi.php');

if (!isset($_SESSION['user_id'])) {
    // Jika belum login, arahkan ke halaman login
    header("Location: ../user/login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // ambil ID user yang login

// === PERUBAHAN QUERY: Tambahkan p.link_classroom ===
$query = "
SELECT
    t.transaksi_id,
    p.nama_paket,
    p.harga,
    p.link_classroom, 
    t.total_bayar,
    t.status_transaksi,
    pm.status_validasi,
    pm.tanggal_bayar,
    t.tanggal_transaksi
FROM transaksi t
JOIN paket_bimbel p ON t.paket_id = p.paket_id
LEFT JOIN pembayaran pm ON t.transaksi_id = pm.transaksi_id
WHERE t.user_id = '$user_id'
ORDER BY t.tanggal_transaksi DESC
";


$result = mysqli_query($koneksi, $query);
?>


<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<!-- PENTING: Menambahkan Meta Viewport untuk responsif -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Riwayat Transaksi Saya</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<!-- Menambahkan Font Poppins (agar sama) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

<style>
/* Menggunakan Font Poppins */
body {
    font-family: 'Poppins', sans-serif; 
    
    /* === BACKGROUND SAMA SEPERTI TAMPIL_PAKET.PHP === */
    background-color: #a18cd1; /* Fallback */
    background-image: 
        repeating-linear-gradient(
            -45deg, 
            rgba(255,255,255,0.05), 
            rgba(255,255,255,0.05) 10px, 
            transparent 10px, 
            transparent 20px
        ),
        linear-gradient(135deg, #fbc2eb 0%, #a18cd1 100%);
    min-height: 100vh;
    /* === AKHIR PERUBAHAN BACKGROUND === */
}
.card {
    /* Kartu dibuat putih solid agar kontras dengan background */
    background-color: #ffffff; 
    border: none;
    border-radius: 16px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}
.status-badge {
    padding: 6px 10px;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
}
.status-pending {
    background-color: #fff3cd;
    color: #856404;
}
.status-success {
    background-color: #d4edda;
    color: #155724;
}
.status-reject {
    background-color: #f8d7da;
    color: #721c24;
}

/* Style baru untuk tombol link classroom */
.btn-classroom {
    background-color: #0d6efd; /* Biru */
    color: #fff;
    font-weight: 600;
    font-size: 0.9rem;
    padding: 6px 10px;
    border-radius: 10px;
    text-decoration: none;
    transition: background-color 0.2s;
}
.btn-classroom:hover {
    background-color: #0b5ed7;
    color: #fff;
}
</style>
</head>
<body>

<div class="container py-5">
    <!-- Mengubah flex-wrap agar tombol bisa stack di mobile -->
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <!-- Judul dibuat text-dark agar terbaca jelas -->
        <h3 class="fw-bold text-dark mb-0">📦 Riwayat Transaksi Saya</h3>
        <div class="text-nowrap">
            <!-- Tombol Kembali dan Logout dirapikan jadi satu -->
            <a href="../paket/tampil_paket.php" class="btn btn-outline-secondary btn-sm me-2">← Kembali ke Paket</a>
            <a href="../user/logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>

    <!-- Padding di HP dikurangi (p-3), di desktop tetap (p-md-4) -->
    <div class="card p-3 p-md-4">
        
        <!-- INI SOLUSINYA: Bungkus tabel dengan .table-responsive -->
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>ID Transaksi</th>
                        <th>Paket</th>
                        <th>Harga</th>
                        <th>Tanggal</th>
                        <th>Status Pembayaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td class="text-center fw-bold"><?= htmlspecialchars($row['transaksi_id']) ?></td>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($row['nama_paket'] ?? '-') ?></div>
                                </td>
                                <td class="text-center">Rp <?= number_format($row['harga'] ?? 0, 0, ',', '.') ?></td>
                                <td class="text-center"><?= htmlspecialchars(date('d M Y', strtotime($row['tanggal_transaksi'] ?? $row['tanggal_bayar']))) ?></td>
                                
                                <!-- ============================================= -->
                                <!--         PERUBAHAN LOGIKA STATUS/LINK          -->
                                <!-- ============================================= -->
                                <td class="text-center">
                                    <?php
                                        // Tentukan status utama
                                        $status = $row['status_validasi'] ?? $row['status_transaksi'] ?? 'Menunggu Pembayaran';

                                        // Cek jika status 'Valid' (sudah disetujui)
                                        if ($status == 'Valid' || $status == 'Disetujui') {
                                            
                                            // 1. Tampilkan badge "Valid" (hijau)
                                            echo '<span class="status-badge status-success">Valid</span>';
                                            
                                            // 2. Cek apakah admin sudah input link
                                            if (!empty($row['link_classroom'])) {
                                                // 3. Tampilkan tombol link DI BAWAHNYA
                                                echo '<div class="mt-2">
                                                        <a href="' . htmlspecialchars($row['link_classroom']) . '" target="_blank" class="btn-classroom">
                                                            <i class="bi bi-google-play"></i> Masuk Kelas
                                                        </a>
                                                      </div>';
                                            } else {
                                                // 3b. (Opsional) Kasih tau user linknya belum ada
                                                echo '<div class="text-muted small mt-1">(Link kelas sedang disiapkan)</div>';
                                            }

                                        } elseif ($status == 'Ditolak') {
                                            // Tampilkan badge "Ditolak" (merah)
                                            echo '<span class="status-badge status-reject">Ditolak</span>';
                                        
                                        } else {
                                            // Status 'Menunggu Validasi' atau 'Menunggu Pembayaran'
                                            echo '<span class="status-badge status-pending">' . htmlspecialchars($status) . '</span>';
                                        }
                                    ?>
                                </td>
                                <!-- ============================================= -->
                                <!--               AKHIR PERUBAHAN                 -->
                                <!-- ============================================= -->
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted p-4">Belum ada transaksi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- AKHIR .table-responsive -->

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>