<?php
include '../config/koneksi.php';
session_start();

// Pengecekan sesi admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// Query untuk mengambil semua data user
$query = "SELECT * FROM user ORDER BY tanggal_daftar DESC";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Data User - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --text-dark: #2d3748;
            --text-light: #718096;
            
            /* Variabel BG dari Dashboard Admin */
            --bg-gradient-start: #f0f4f9; 
            --bg-gradient-end: #d9e2ec;   
            --card-bg: #FFFFFF;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            min-height: 100vh;

            /* === PERUBAHAN BACKGROUND (DOT PATTERN) === */
            background-color: var(--bg-gradient-start); 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cg fill='%23d9e2ec'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/svg%3E");
            background-position: center;
            background-repeat: repeat;
            /* === AKHIR PERUBAHAN === */
        }

        .navbar-admin {
            background-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }

        .content-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            overflow: hidden; 
            background-color: var(--card-bg);
        }

        .table th {
            color: var(--text-light);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            border-top: none;
            border-bottom: 2px solid #e9ecef;
        }
        
        .table td {
            vertical-align: middle;
            padding: 1rem 1.25rem;
            border-top: 1px solid #e9ecef;
        }

        .table tbody tr {
            background-color: #fff;
        }
    </style>
</head>
<body>

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="dashboard.php">Bimbel UTBK - Admin Panel</a>
        <div class="d-flex">
            <span class="navbar-text text-white me-3">
                Halo, <b><?= htmlspecialchars($_SESSION['nama_admin']); ?></b> 👋
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4" data-aos="fade-up">
        <h3 class="fw-bold mb-0">Kelola Data User</h3>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">← Kembali ke Dashboard</a>
    </div>

    <div class="content-card" data-aos="fade-up" data-aos-delay="100">
        <div class="card-body p-0 p-md-3">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="text-center">
                        <tr>
                            <th>User ID</th>
                            <th>Nama User</th>
                            <th>Email</th>
                            <th>No. Telepon</th>
                            <th>Alamat</th>
                            <th>Tanggal Daftar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= htmlspecialchars($row['user_id']); ?></td>
                                    <td><?= htmlspecialchars($row['nama']); ?></td>
                                    <td><?= htmlspecialchars($row['email']); ?></td>
                                    <td class="text-center"><?= htmlspecialchars($row['no_telp']); ?></td>
                                    <td><?= htmlspecialchars($row['alamat']); ?></td>
                                    <td class="text-center"><?= htmlspecialchars(date('d M Y', strtotime($row['tanggal_daftar']))); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted p-5">
                                    <h5 class="mb-0">Belum ada user terdaftar.</h5>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
        duration: 600,
        once: true
    });
</script>

</body>
</html>