<?php
session_start();
// KONEKSI DATABASE (WAJIB ADA)
include '../config/koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// --- 1. AMBIL DATA STATISTIK UNTUK KARTU ---

// Hitung jumlah yang perlu divalidasi
$q_validasi = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pembayaran WHERE status_validasi = 'Menunggu Validasi'");
$count_validasi = mysqli_fetch_assoc($q_validasi)['total'] ?? 0;

// Hitung total user
$q_users = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM user");
$count_users = mysqli_fetch_assoc($q_users)['total'] ?? 0;

// Hitung total pendapatan (hanya dari transaksi yang sudah Valid/Disetujui)
$q_pendapatan = mysqli_query($koneksi, "SELECT SUM(total_bayar) as total FROM transaksi WHERE status_transaksi = 'Valid' OR status_transaksi = 'Disetujui'");
$total_pendapatan = mysqli_fetch_assoc($q_pendapatan)['total'] ?? 0;

// Hitung total transaksi
$q_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM transaksi");
$count_transaksi = mysqli_fetch_assoc($q_transaksi)['total'] ?? 0;


// --- 2. AMBIL 5 TRANSAKSI TERBARU UNTUK TABEL ---
$q_recent = mysqli_query($koneksi, "
    SELECT t.transaksi_id, u.nama, t.total_bayar, t.status_transaksi
    FROM transaksi t
    JOIN user u ON t.user_id = u.user_id
    ORDER BY t.tanggal_transaksi DESC
    LIMIT 5
");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Bimbel UTBK</title>
    
    <!-- CSS Wajib -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- BARU: Link untuk Ikon Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Library Animasi & Notifikasi -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <style>
        :root {
            --primary-color: #0052D4; 
            --secondary-color: #FFB700;
            --success-color: #059669; 
            --danger-color: #DC3545;
            --info-color: #3b82f6;
            --purple-color: #6d28d9; /* Warna baru untuk paket */
            --text-dark: #2d3748;
            --text-light: #718096;
            
            --bg-gradient-start: #f0f4f9; 
            --bg-gradient-end: #d9e2ec;   
            
            --card-bg: #FFFFFF; 
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            min-height: 100vh;
            
            background-color: var(--bg-gradient-start); 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cg fill='%23d9e2ec'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/svg%3E");
            background-position: center;
            background-repeat: repeat;
        }

        .navbar-admin {
            background-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }

        .dashboard-card {
            color: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            transition: all 0.3s ease;
            padding: 1.5rem;
            height: 100%; 
            display: flex;
            flex-direction: column;
            position: relative; 
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
        }
        
        .card-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            display: block;
            color: #FFFFFF;
            opacity: 0.8; 
        }
        
        /* Kelas Warna Kartu */
        .card-validasi { background: linear-gradient(135deg, #FFB700 0%, #f7971e 100%); }
        .card-user { background: linear-gradient(135deg, #3b82f6 0%, #0052D4 100%); }
        .card-pendapatan { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .card-transaksi { background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%); }
        /* BARU: Warna Kartu Kelola Paket */
        .card-paket { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); } 


        .stat-number {
            font-size: 2.25rem;
            font-weight: 700;
            color: #FFFFFF; 
            margin-bottom: 0.25rem;
        }
        
        .card-title-link {
            font-weight: 600;
            color: #FFFFFF; 
            font-size: 1.15rem;
            text-decoration: none;
        }
        .card-title-link:hover {
            color: #FFFFFF;
            text-decoration: underline; 
        }
        .card-text {
            color: rgba(255, 255, 255, 0.8); 
            font-size: 0.95rem;
            flex-grow: 1; 
        }
        
        .content-card {
             background-color: var(--card-bg);
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            overflow: hidden; 
        }

        /* Styling Tabel */
        .table-responsive { margin-bottom: 0; }
        .table { margin-bottom: 0; }
        .table th {
            color: var(--text-light); font-weight: 600; text-transform: uppercase;
            font-size: 0.8rem; border-top: none; border-bottom: 2px solid #e9ecef;
        }
        .table td {
            vertical-align: middle; padding: 1rem 1.25rem;
            border-top: 1px solid #e9ecef; color: var(--text-dark);
        }
        .table tbody tr:last-child td { border-bottom: none; }
        
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">Bimbel UTBK - Admin Panel</a>
        <div class="d-flex">
            <span class="navbar-text text-white me-3">
                Halo, <b><?= htmlspecialchars($_SESSION['nama_admin']); ?></b> 👋
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5 py-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4" data-aos="fade-down">
        <div>
            <h2 class="fw-bold">Selamat Datang, Admin!</h2>
            <p class="text-muted mb-0">Ringkasan aktivitas bimbel hari ini.</p>
        </div>
        <div>
            <a href="tampil_admin.php" class="btn btn-primary shadow-sm">
                <i class="bi bi-person-gear"></i> Kelola Admin
            </a>
        </div>
    </div>

    <!-- 
      KARTU STATISTIK
      Menggunakan row-cols-lg-5 agar 5 kartu muat dalam satu baris di layar besar
    -->
    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-5 g-4">
        
        <!-- Kartu 1: Validasi Pembayaran -->
        <div class="col" data-aos="fade-up" data-aos-delay="100">
            <div class="dashboard-card card-validasi">
                <i class="bi bi-patch-check-fill card-icon"></i>
                <h3 class="stat-number"><?= $count_validasi ?></h3>
                <p class="card-text">Perlu Divalidasi</p>
                <a href="validasi_transaksi.php" class="card-title-link stretched-link">
                    Validasi <i class="bi bi-arrow-right-short"></i>
                </a>
            </div>
        </div>

        <!-- Kartu 2: Total User -->
        <div class="col" data-aos="fade-up" data-aos-delay="200">
            <div class="dashboard-card card-user">
                <i class="bi bi-people-fill card-icon"></i>
                <h3 class="stat-number"><?= $count_users ?></h3>
                <p class="card-text">Total User</p>
                <a href="tampil_user.php" class="card-title-link stretched-link">
                    Lihat User <i class="bi bi-arrow-right-short"></i>
                </a>
            </div>
        </div>

        <!-- Kartu 3: Total Pendapatan -->
        <div class="col" data-aos="fade-up" data-aos-delay="300">
            <div class="dashboard-card card-pendapatan">
                <i class="bi bi-bar-chart-line-fill card-icon"></i>
                <h3 class="stat-number">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></h3>
                <p class="card-text">Pendapatan (Valid)</p>
                <a href="log_admin.php" class="card-title-link stretched-link">
                    Lihat Log <i class="bi bi-arrow-right-short"></i>
                </a>
            </div>
        </div>
        
        <!-- Kartu 4: Total Transaksi -->
        <div class="col" data-aos="fade-up" data-aos-delay="400">
            <div class="dashboard-card card-transaksi">
                <i class="bi bi-receipt-cutoff card-icon"></i>
                <h3 class="stat-number"><?= $count_transaksi ?></h3>
                <p class="card-text">Total Transaksi</p>
                <a href="laporan_transaksi.php" class="card-title-link stretched-link">
                    Kelola <i class="bi bi-arrow-right-short"></i>
                </a>
            </div>
        </div>
        
        <!-- ============================================= -->
        <!--           KARTU BARU UNTUK KELOLA PAKET         -->
        <!-- ============================================= -->
        <div class="col" data-aos="fade-up" data-aos-delay="500">
            <div class="dashboard-card card-paket">
                <i class="bi bi-google-play card-icon"></i>
                <h3 class_ ="stat-number">&nbsp;</h3> <!-- Spacer -->
                <p class="card-text">Atur Link Google Classroom</p>
                <a href="kelola_paket.php" class="card-title-link stretched-link">
                    Kelola Paket <i class="bi bi-arrow-right-short"></i>
                </a>
            </div>
        </div>
        <!-- ============================================= -->
        <!--           AKHIR KARTU BARU                  -->
        <!-- ============================================= -->

    </div>
    
    <!-- TABEL AKTIVITAS TERBARU (Tetap putih) -->
    <div class="row mt-5">
        <div class="col-12" data-aos="fade-up" data-aos-delay="600">
            <div class="content-card">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Aktivitas Transaksi Terbaru</h5>
                    
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th>ID Transaksi</th>
                                    <th>Nama User</th>
                                    <th>Total Bayar</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($q_recent) > 0): ?>
                                    <?php while ($row = mysqli_fetch_assoc($q_recent)): ?>
                                        <tr>
                                            <td class="fw-bold"><?= htmlspecialchars($row['transaksi_id']); ?></td>
                                            <td><?= htmlspecialchars($row['nama']); ?></td>
                                            <td class="fw-semibold">Rp <?= number_format($row['total_bayar'], 0, ',', '.'); ?></td>
                                            <td>
                                                <!-- Logika Badge Warna-warni -->
                                                <?php
                                                    $status = $row['status_transaksi'];
                                                    $badge_class = 'bg-secondary';
                                                    if ($status == 'Valid' || $status == 'Disetujui') {
                                                        $badge_class = 'bg-success';
                                                    } elseif ($status == 'Ditolak' || $status == 'Gagal') {
                                                        $badge_class = 'bg-danger';
                                                    } elseif (str_contains($status, 'Menunggu')) {
                                                        $badge_class = 'bg-warning text-dark';
                                                    }
                                                ?>
                                                <span class="badge <?= $badge_class; ?>">
                                                    <?= htmlspecialchars($status); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted p-4">
                                            Belum ada aktivitas transaksi.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>

<!-- JS Wajib untuk Animasi & Notifikasi -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Inisialisasi Animasi -->
<script>
    AOS.init({
        duration: 700,
        once: true
    });
</script>

<!-- Logika untuk Notifikasi "Login Berhasil" -->
<?php
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    echo "
    <script>
        Swal.fire({
            icon: '" . $message['type'] . "',
            title: '" . $message['title'] . "',
            text: '" . $message['text'] . "',
            timer: 2500,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    </script>
    ";
    // Hapus pesan setelah ditampilkan
    unset($_SESSION['flash_message']);
}
?>

</body>
</html>