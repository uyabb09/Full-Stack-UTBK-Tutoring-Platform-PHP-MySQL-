<?php
include '../config/koneksi.php';
session_start();

// Pengecekan sesi admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// 1. Ambil ID dari URL
if (isset($_GET['id'])) {
    $transaksi_id = $_GET['id'];
    $transaksi_id_esc = mysqli_real_escape_string($koneksi, $transaksi_id);

    // 2. (PENTING) Hapus data "anak" terlebih dahulu
    
    // 2a. Hapus dari tabel 'laporan'
    mysqli_query($koneksi, "DELETE FROM laporan WHERE transaksi_id = '$transaksi_id_esc'");

    // 2b. Cari nama file bukti bayar SEBELUM dihapus
    $q_bukti = mysqli_query($koneksi, "SELECT bukti_bayar FROM pembayaran WHERE transaksi_id = '$transaksi_id_esc'");
    if (mysqli_num_rows($q_bukti) > 0) {
        $data_bukti = mysqli_fetch_assoc($q_bukti);
        $nama_file_bukti = $data_bukti['bukti_bayar'];
        
        // Hapus file fisik dari folder /uploads
        $file_path = __DIR__ . "/../uploads/" . $nama_file_bukti; 
        if (!empty($nama_file_bukti) && file_exists($file_path)) {
            @unlink($file_path); // @unlink akan mencoba menghapus file tanpa memicu error jika gagal
        }
    }
    
    // 2c. Hapus dari tabel 'pembayaran'
    mysqli_query($koneksi, "DELETE FROM pembayaran WHERE transaksi_id = '$transaksi_id_esc'");

    // 3. Hapus data "induk" di 'transaksi'
    $delete_main = mysqli_query($koneksi, "DELETE FROM transaksi WHERE transaksi_id = '$transaksi_id_esc'");

    if ($delete_main) {
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Transaksi ' . htmlspecialchars($transaksi_id) . ' telah dihapus.'
        ];
    } else {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'title' => 'Gagal',
            'text' => 'Gagal menghapus transaksi.' . mysqli_error($koneksi)
        ];
    }
    
} else {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'title' => 'Error',
        'text' => 'ID Transaksi tidak ditemukan.'
    ];
}

// 4. Kembalikan ke halaman daftar transaksi
// Pastikan nama file ini (laporan_transaksi.php) sesuai dengan nama file-mu
header("Location: laporan_transaksi.php"); 
exit;
?>