<?php
session_start();
include '../config/koneksi.php';

// Jika admin sudah login, langsung ke dashboard
if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error_msg = '';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = $_POST['password']; // Ambil password mentah

    // 1. Ambil data HANYA berdasarkan username
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username = '$username'");

    if (mysqli_num_rows($query) === 1) {
        $data = mysqli_fetch_assoc($query);

        // 2. Verifikasi password hash
        if (password_verify($password, $data['password'])) {
            // --- LOGIN BERHASIL ---
            $_SESSION['admin_id'] = $data['admin_id'];
            $_SESSION['nama_admin'] = $data['nama_admin']; // Simpan nama admin
            
            // Notifikasi (opsional tapi bagus)
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'title' => 'Login Berhasil!',
                'text' => 'Selamat datang kembali, ' . htmlspecialchars($data['nama_admin'])
            ];
            
            header("Location: dashboard.php");
            exit;
        } else {
            // Password tidak cocok
            $error_msg = "Username atau password salah!";
        }
    } else {
        // Username tidak ditemukan
        $error_msg = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Bimbel UTBK</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- BARU: Link untuk Ikon Mata (Bootstrap Icons) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --text-dark: #2d3748;
        }

        body { 
            font-family: 'Inter', sans-serif;
            
            /* === BACKGROUND SAMA SEPERTI TAMPIL_PAKET.PHP === */
            background-color: #a18cd1; /* Fallback */
            background-image: 
                repeating-linear-gradient(
                    -45deg, 
                    rgba(255,255,255,0.05), 
                    rgba(255,255,255,0.05) 10px, 
                    transparent 10px, 
                    transparent 20px
                ),
                linear-gradient(135deg, #fbc2eb 0%, #a18cd1 100%);
            /* === AKHIR BACKGROUND === */

            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            padding: 2rem 0;
        }
        .card-login { 
            width: 100%; 
            max-width: 400px; 
            border: none; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
            background-color: #ffffff;
        }
        
        /* Style untuk input dan tombol */
        .form-control {
            padding: 0.75rem 1rem;
            border: 1px solid #ddd;
            border-radius: 0; /* Hapus radius di sini */
        }
        
        .form-control:not(.input-group .form-control) {
            border-radius: 10px; /* Terapkan radius 10px di sini */
        }
        
        .input-group {
            border-radius: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
            overflow: hidden; 
        }
        .input-group .form-control { border: none; }
        .input-group .input-group-text { border: none; background-color: #fff; cursor: pointer; }
        
        .input-group:focus-within,
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(0, 82, 212, 0.1);
        }

        .btn-primary { 
            background-color: var(--primary-color); 
            border: none; 
            padding: 12px; 
            font-weight: 600; 
            border-radius: 10px;
        }
        .btn-primary:hover { 
            background-color: #0041a8; 
        }
    </style>
</head>
<body>
    <div class="card card-login p-4">
        <div class="card-body">
            <h3 class="text-center fw-bold mb-4">Login Admin</h3>

            <?php if (!empty($error_msg)): ?>
                <div class="alert alert-danger py-2 text-center" role="alert">
                    <?= $error_msg; ?>
                </div>
            <?php endif; ?>

            <form action="login_admin.php" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label fw-semibold">Username</label>
                    <input type="text" class="form-control" style="border-radius: 10px;" id="username" name="username" required>
                </div>

                <!-- KOLOM PASSWORD DENGAN IKON MATA -->
                <div class="mb-4">
                    <label for="password" class="form-label fw-semibold">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="passwordInput" name="password" required>
                        <span class="input-group-text" id="togglePassword">
                            <i class="bi bi-eye-slash-fill"></i>
                        </span>
                    </div>
                </div>
                <!-- AKHIR KOLOM PASSWORD -->

                <button type="submit" name="login" class="btn btn-primary w-100 mb-3">Login</button>
            </form>
            <div class="text-center">
                <p class="mt-2"><a href="../index.php" class="text-muted text-decoration-none small"> Kembali ke Menu Awal</a></p>
            </div>
        </div>
    </div>

<!-- Script untuk Toggle Password -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('passwordInput');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function () {
                const icon = this.querySelector('i');
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                if (type === 'password') {
                    icon.classList.remove('bi-eye-fill');
                    icon.classList.add('bi-eye-slash-fill');
                } else {
                    icon.classList.remove('bi-eye-slash-fill');
                    icon.classList.add('bi-eye-fill');
                }
            });
        }
    });
</script>
</body>
</html>