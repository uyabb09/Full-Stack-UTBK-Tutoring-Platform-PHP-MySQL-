<?php
session_start();
include '../config/koneksi.php';

// 1. Cek Sesi Admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// 2. Ambil ID Admin yang sedang login (untuk keamanan)
$current_admin_id = $_SESSION['admin_id'];

// 3. Ambil ID admin yang mau dihapus dari URL
if (isset($_GET['id'])) {
    $admin_to_delete_id = mysqli_real_escape_string($koneksi, $_GET['id']);

    // 4. (SANGAT PENTING) Cek Keamanan: Admin tidak boleh menghapus dirinya sendiri
    if ($admin_to_delete_id == $current_admin_id) {
        // Gagal, kembali ke halaman tampil admin dengan pesan error
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'title' => 'Aksi Gagal',
            'text' => 'Anda tidak dapat menghapus akun Anda sendiri!'
        ];
        header("Location: tampil_admin.php");
        exit;
    }

    // 5. (PENTING) Hapus data "anak" dulu (di tabel laporan) agar tidak error foreign key
    mysqli_query($koneksi, "DELETE FROM laporan WHERE admin_id = '$admin_to_delete_id'");

    // 6. Hapus data "induk" (admin)
    $query_hapus = mysqli_query($koneksi, "DELETE FROM admin WHERE admin_id = '$admin_to_delete_id'");

    if ($query_hapus) {
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Admin telah dihapus.'
        ];
    } else {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'title' => 'Gagal',
            'text' => 'Gagal menghapus admin: ' . mysqli_error($koneksi)
        ];
    }

} else {
    // ID tidak ditemukan di URL
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'title' => 'Error',
        'text' => 'ID Admin tidak ditemukan.'
    ];
}

// 7. Kembalikan ke halaman daftar admin
header("Location: tampil_admin.php");
exit;
?>