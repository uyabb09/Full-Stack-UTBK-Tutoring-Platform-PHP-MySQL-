<?php
session_start();
include '../config/koneksi.php';

// Cek sesi admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// Proses UPDATE jika form disubmit
if (isset($_POST['update_link'])) {
    $paket_id = mysqli_real_escape_string($koneksi, $_POST['paket_id']);
    $link_classroom = mysqli_real_escape_string($koneksi, $_POST['link_classroom']);

    $query_update = "UPDATE paket_bimbel SET link_classroom = '$link_classroom' WHERE paket_id = '$paket_id'";
    
    if (mysqli_query($koneksi, $query_update)) {
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'title' => 'Berhasil!',
            'text' => 'Link classroom telah diperbarui.'
        ];
    } else {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'title' => 'Gagal',
            'text' => 'Gagal memperbarui link.'
        ];
    }
    // Redirect ke halaman ini lagi untuk refresh data
    header("Location: kelola_paket.php");
    exit;
}

// Ambil semua data paket
$query = "SELECT * FROM paket_bimbel ORDER BY harga ASC";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Paket Bimbel - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --text-dark: #2d3748;
            --text-light: #718096;
            --bg-gradient-start: #f0f4f9; 
            --bg-gradient-end: #d9e2ec;   
            --card-bg: #FFFFFF;
        }
        body {
            font-family: 'Inter', sans-serif; color: var(--text-dark); min-height: 100vh;
            background-color: var(--bg-gradient-start); 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cg fill='%23d9e2ec'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/svg%3E");
            background-position: center;
        }
        .navbar-admin {
            background-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }
        .content-card {
            border: none; border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            background-color: var(--card-bg);
        }
    </style>
</head>
<body>

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="dashboard.php">Bimbel UTBK - Admin Panel</a>
        <div class="d-flex">
            <span class="navbar-text text-white me-3">
                Halo, <b><?= htmlspecialchars($_SESSION['nama_admin']); ?></b> 👋
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Kelola Link Classroom</h3>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">← Kembali ke Dashboard</a>
    </div>

    <div class="content-card">
        <div class="card-body p-4">
            <p class="text-muted">Di sini Anda dapat mengatur link Google Classroom (atau link pembelajaran lainnya) untuk setiap paket.</p>
            
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($paket = mysqli_fetch_assoc($result)): ?>
                    <form method="POST" action="kelola_paket.php">
                        <input type="hidden" name="paket_id" value="<?= $paket['paket_id']; ?>">
                        <div class="mb-4 p-3 border rounded-3">
                            <label class="form-label fw-bold fs-5"><?= htmlspecialchars($paket['nama_paket']); ?></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-link-45deg"></i></span>
                                <input type="url" class="form-control" name="link_classroom" 
                                       placeholder="https://classroom.google.com/..." 
                                       value="<?= htmlspecialchars($paket['link_classroom'] ?? ''); ?>">
                                <button type="submit" name="update_link" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-center text-muted">Belum ada data paket bimbel.</p>
            <?php endif; ?>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Script Notifikasi (Flash Message) -->
<?php
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    echo "
    <script>
        Swal.fire({
            icon: '" . $message['type'] . "',
            title: '" . $message['title'] . "',
            text: '" . $message['text'] . "',
            timer: 2000,
            showConfirmButton: false
        });
    </script>
    ";
    // Hapus pesan setelah ditampilkan
    unset($_SESSION['flash_message']);
}
?>
</body>
</html>