<?php
include '../config/koneksi.php';
session_start(); // Tambahkan session start

// TAMBAHKAN: Pengecekan Sesi Admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// BAGIAN 1: PROSES AKSI (Modifikasi untuk SweetAlert)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $transaksi_id = $_GET['id'];
    $status_validasi = "";
    $status_transaksi = "";

    if ($action == 'setujui') {
        $status_validasi = "Valid";
        $status_transaksi = "Valid";
    } elseif ($action == 'tolak') {
        $status_validasi = "Ditolak";
        $status_transaksi = "Ditolak";
    }

    if (!empty($status_validasi) && !empty($status_transaksi)) {
    // Update status di tabel pembayaran
    $stmt1 = $koneksi->prepare("UPDATE pembayaran SET status_validasi = ? WHERE transaksi_id = ?");
    $stmt1->bind_param("ss", $status_validasi, $transaksi_id);
    $execute1 = $stmt1->execute();
    $stmt1->close(); // Selalu tutup statement setelah eksekusi

    // Update status di tabel transaksi
    $stmt2 = $koneksi->prepare("UPDATE transaksi SET status_transaksi = ? WHERE transaksi_id = ?");
    $stmt2->bind_param("ss", $status_transaksi, $transaksi_id);
    $execute2 = $stmt2->execute();
    $stmt2->close(); // Selalu tutup statement setelah eksekusi

    // Sisa flash message seperti biasa
    if ($execute1 && $execute2) {
        
        // === TAMBAHAN UNTUK LOG ===
        // Jika update berhasil, kita buat entri log di tabel 'laporan'
        
        // 1. Siapkan data untuk log
        $laporan_id_baru = strtoupper('L' . substr(uniqid(), -7)); // Buat ID Laporan unik cth: L1A2B3C
        $admin_id_log     = $_SESSION['admin_id'];
        $nama_admin_log   = $_SESSION['nama_admin'];
        $transaksi_id_log = $transaksi_id;
        $tanggal_sekarang = date('Y-m-d H:i:s'); // Sesuai struktur tabel Anda (tipe DATE)
        
        // Buat keterangan log yang dinamis
        $keterangan_aksi = ($action == 'setujui') ? 'Disetujui' : 'Ditolak';
        $keterangan_log   = "Admin ($nama_admin_log) mengubah status transaksi $transaksi_id_log menjadi '$keterangan_aksi'.";

        // 2. Buat prepared statement untuk INSERT log (agar aman)
        $stmt_log = $koneksi->prepare("INSERT INTO laporan (laporan_id, admin_id, transaksi_id, tanggal_laporan, keterangan) 
                                       VALUES (?, ?, ?, ?, ?)");
        
        // 3. Bind parameter (semua string 's')
        $stmt_log->bind_param("sssss",
            $laporan_id_baru,
            $admin_id_log,
            $transaksi_id_log,
            $tanggal_sekarang,
            $keterangan_log
        );
        
        // 4. Eksekusi query log
        $stmt_log->execute();
        $stmt_log->close();
        // === AKHIR TAMBAHAN LOG ===


        // Ini kode notifikasi SweetAlert Anda yang sudah ada
        $_SESSION['flash_message'] = [
            'type' => 'success',
            'title' => 'Aksi Berhasil!',
            'text' => 'Status transaksi ' . htmlspecialchars($transaksi_id) . ' telah diubah.'
        ];
    } else {
        $_SESSION['flash_message'] = [
            'type' => 'error',
            'title' => 'Aksi Gagal',
            'text' => 'Gagal memperbarui database.'
        ];
    }
    header('Location: validasi_transaksi.php');
    exit;
    }
}

// BAGIAN 2: TAMPILKAN DAFTAR (Query asli Anda)
$query = "
SELECT 
    pembayaran_id,
    transaksi_id,
    tanggal_bayar, 
    status_validasi,
    bukti_bayar,
    nominal
FROM pembayaran
WHERE status_validasi = 'Menunggu Validasi'
ORDER BY tanggal_bayar ASC
";
$result = mysqli_query($koneksi, $query) or die(mysqli_error($koneksi)); 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Validasi Pembayaran - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --text-dark: #2d3748;
            --text-light: #718096;
            
            /* Variabel BG dari Dashboard Admin */
            --bg-gradient-start: #f0f4f9; 
            --bg-gradient-end: #d9e2ec;   
            --card-bg: #FFFFFF;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            min-height: 100vh;

            /* === PERUBAHAN BACKGROUND DI SINI === */
            /* Warna dasar solid (dari gradient start) */
            background-color: var(--bg-gradient-start); 
            /* Pola titik-titik (menggunakan warna gradient end) */
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cg fill='%23d9e2ec'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/svg%3E");
            background-position: center;
            background-repeat: repeat;
            /* === AKHIR PERUBAHAN === */
        }

        /* Navbar Kustom Sesuai Admin */
        .navbar-admin {
            background-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }

        /* Kartu Konten */
        .content-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            overflow: hidden; 
            background-color: var(--card-bg);
        }

        .table th {
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.8rem;
            text-transform: uppercase;
            border-top: none;
            border-bottom: 2px solid #e9ecef;
        }

        .table td {
            vertical-align: middle;
        }
        
        /* Styling Gambar Bukti */
        .bukti-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border: 1px solid #ddd;
            border-radius: 8px;
            transition: transform 0.2s;
        }
        .bukti-img:hover {
            transform: scale(1.1);
        }
    </style>
</head>
<body>

<!-- Navbar Admin (Konsisten) -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="dashboard.php">Bimbel UTBK - Admin Panel</a>
        <div class="d-flex">
            <span class="navbar-text text-white me-3">
                Halo, <b><?= htmlspecialchars($_SESSION['nama_admin']); ?></b> 👋
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4" data-aos="fade-in">
        <h3 class="fw-bold text-dark">Validasi Pembayaran</h3>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">← Kembali ke Dashboard</a>
    </div>

    <div class="card content-card" data-aos="fade-up" data-aos-delay="100">
        <div class="card-body p-0 p-md-3">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="text-center">
                        <tr>
                            <th>ID Transaksi</th>
                            <th>Nominal</th>
                            <th>Tgl. Bayar</th>
                            <th>Status</th>
                            <th>Bukti</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= htmlspecialchars($row['transaksi_id']) ?></td>
                                    <td class="text-end">Rp <?= number_format($row['nominal'], 0, ',', '.') ?></td>
                                    <td class="text-center"><?= htmlspecialchars(date('d M Y', strtotime($row['tanggal_bayar']))) ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-warning text-dark"><?= htmlspecialchars($row['status_validasi']) ?></span>
                                    </td>
                                    <td class="text-center">
                                        <a href="../uploads/<?= htmlspecialchars($row['bukti_bayar']) ?>" target="_blank">
                                            <img src="../uploads/<?= htmlspecialchars($row['bukti_bayar']) ?>" alt="Bukti" class="bukti-img">
                                        </a>
                                    </td>
                                    <td class="text-center">
                                        <a href="validasi_transaksi.php?action=setujui&id=<?= $row['transaksi_id'] ?>" class="btn btn-success btn-sm m-1">Setujui</a>
                                        <a href="validasi_transaksi.php?action=tolak&id=<?= $row['transaksi_id'] ?>" class="btn btn-danger btn-sm m-1">Tolak</a>
                                    </td>
                                 </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted p-5">Tidak ada data pembayaran yang menunggu validasi.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    AOS.init({
        duration: 600,
        once: true
    });
</script>

<!-- Tampilkan Notifikasi Aksi (JIKA ADA) -->
<?php
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    echo "
    <script>
        Swal.fire({
            icon: '" . $message['type'] . "',
            title: '" . $message['title'] . "',
            text: '" . $message['text'] . "',
            timer: 3000,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    </script>
    ";
    // Hapus pesan setelah ditampilkan
    unset($_SESSION['flash_message']);
}
?>

</body>
</html>