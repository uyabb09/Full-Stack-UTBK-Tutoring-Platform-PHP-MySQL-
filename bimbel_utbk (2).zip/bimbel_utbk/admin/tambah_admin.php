<?php
include '../config/koneksi.php';
session_start();

// Pengecekan sesi admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

$error_message = '';

// Proses form jika disubmit
if (isset($_POST['tambah'])) {
    $admin_id = strtoupper('AJ' . substr(uniqid(), -6)); // Buat ID Admin cth: AJ1A2B3C
    $nama_admin = mysqli_real_escape_string($koneksi, $_POST['nama_admin']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    
    // Hash password menggunakan BCRYPT
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Cek duplikasi username
    $cek_username = mysqli_query($koneksi, "SELECT username FROM admin WHERE username='$username'");
    if (mysqli_num_rows($cek_username) > 0) {
        $error_message = "Username '$username' sudah terdaftar. Silakan gunakan username lain.";
    } else {
        // Query Insert
        $query = "INSERT INTO admin (admin_id, nama_admin, username, email, password)
                  VALUES ('$admin_id', '$nama_admin', '$username', '$email', '$password')";
        
        $simpan = mysqli_query($koneksi, $query);

        if ($simpan) {
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'title' => 'Berhasil!',
                'text' => 'Admin baru telah ditambahkan.'
            ];
            header("Location: tampil_admin.php");
            exit;
        } else {
            $error_message = "Gagal mendaftar. Terjadi kesalahan pada server.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Admin Baru</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Style Admin Panel (Sama seperti file lain) -->
    <style>
        :root {
            --primary-color: #0052D4; 
            --text-dark: #2d3748;
            --text-light: #718096;
            --bg-gradient-start: #f0f4f9; 
            --bg-gradient-end: #d9e2ec;   
            --card-bg: #FFFFFF;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            min-height: 100vh;
            background-color: var(--bg-gradient-start); 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cg fill='%23d9e2ec'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/svg%3E");
            background-position: center;
        }
        .navbar-admin {
            background-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }
        .content-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            background-color: var(--card-bg);
            max-width: 600px; /* Batasi lebar form */
            margin: 0 auto;
        }
        .form-control:focus, .form-select:focus, .input-group:focus-within {
             border-color: var(--primary-color);
             box-shadow: 0 0 0 4px rgba(0, 82, 212, 0.1);
        }
        /* Style untuk toggle password */
        .input-group {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            transition: all 0.3s ease;
        }
        .input-group .form-control { border: none; }
        .input-group .input-group-text { border: none; background-color: #fff; cursor: pointer; }
    </style>
</head>
<body>

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="dashboard.php">Bimbel UTBK - Admin Panel</a>
        <div class="d-flex">
            <span class="navbar-text text-white me-3">
                Halo, <b><?= htmlspecialchars($_SESSION['nama_admin']); ?></b> 👋
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    
    <div class="content-card p-4 p-md-5">
        <h3 class="fw-bold mb-4">Tambah Admin Baru</h3>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label fw-semibold">Nama Lengkap Admin</label>
                <input type="text" name="nama_admin" class="form-control" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold">Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold">Email (Opsional)</label>
                    <input type="email" name="email" class="form-control">
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <input type="password" name="password" id="passwordInput" class="form-control" required>
                    <span class="input-group-text" id="togglePassword">
                        <i class="bi bi-eye-slash-fill"></i>
                    </span>
                </div>
            </div>
            
            <div class="d-flex justify-content-end gap-2 mt-4">
                <a href="tampil_admin.php" class="btn btn-secondary">Batal</a>
                <button type="submit" name="tambah" class="btn btn-primary">Simpan Admin</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Script Toggle Password (Sama seperti di user/daftar.php) -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('passwordInput');
        
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function () {
                const icon = this.querySelector('i');
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                if (type === 'password') {
                    icon.classList.remove('bi-eye-fill');
                    icon.classList.add('bi-eye-slash-fill');
                } else {
                    icon.classList.remove('bi-eye-slash-fill');
                    icon.classList.add('bi-eye-fill');
                }
            });
        }
    });
</script>

</body>
</html>