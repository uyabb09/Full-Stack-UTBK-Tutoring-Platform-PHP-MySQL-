<?php
include '../config/koneksi.php';
session_start();

// Pengecekan sesi admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit;
}

// Query untuk mengambil data transaksi
$query = "
SELECT t.transaksi_id, u.nama, p.nama_paket, t.tanggal_transaksi, t.status_transaksi, t.total_bayar
FROM transaksi t
JOIN user u ON t.user_id = u.user_id
JOIN paket_bimbel p ON t.paket_id = p.paket_id
ORDER BY t.tanggal_transaksi DESC
";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Laporan Transaksi - Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #0052D4; 
            --text-dark: #2d3748;
            --text-light: #718096;
            --bg-gradient-start: #f0f4f9; 
            --bg-gradient-end: #d9e2ec;   
            --card-bg: #FFFFFF;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            min-height: 100vh;
            background-color: var(--bg-gradient-start); 
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cg fill='%23d9e2ec'%3E%3Ccircle cx='10' cy='10' r='2'/%3E%3C/g%3E%3C/svg%3E");
            background-position: center;
            background-repeat: repeat;
        }

        .navbar-admin {
            background-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(0, 82, 212, 0.2);
        }

        .content-card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.07);
            overflow: hidden; 
            background-color: var(--card-bg);
        }

        .table th {
            color: var(--text-light);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            border-top: none;
            border-bottom: 2px solid #e9ecef;
        }
        
        .table td {
            vertical-align: middle;
            padding: 1rem 1.25rem;
            border-top: 1px solid #e9ecef;
        }

        .table tbody tr {
            background-color: #fff;
        }
    </style>
</head>
<body>

<!-- Navbar Admin (Konsisten) -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-admin">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="dashboard.php">Bimbel UTBK - Admin Panel</a>
        <div class="d-flex">
            <span class="navbar-text text-white me-3">
                Halo, <b><?= htmlspecialchars($_SESSION['nama_admin']); ?></b> 👋
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4" data-aos="fade-up">
        <h3 class="fw-bold mb-0">Kelola Laporan Transaksi</h3>
        <div>
            <!-- Tombol Export GAGUNA sudah dihapus -->
            <a href="dashboard.php" class="btn btn-secondary btn-sm">← Kembali ke Dashboard</a>
        </div>
    </div>


    <div class="content-card" data-aos="fade-up" data-aos-delay="100">
        <div class="card-body p-0 p-md-3">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="text-center">
                        <tr>
                            <th>ID Transaksi</th>
                            <th>Nama User</th>
                            <th>Nama Paket</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Total Bayar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= htmlspecialchars($row['transaksi_id']); ?></td>
                                    <td><?= htmlspecialchars($row['nama']); ?></td>
                                    <td><?= htmlspecialchars($row['nama_paket']); ?></td>
                                    <td class="text-center"><?= htmlspecialchars(date('d M Y', strtotime($row['tanggal_transaksi']))); ?></td>
                                    <td class="text-center">
                                        <!-- Logika Badge Warna-warni -->
                                        <?php
                                            $status = $row['status_transaksi'];
                                            $badge_class = 'bg-secondary';
                                            if ($status == 'Valid' || $status == 'Disetujui') {
                                                $badge_class = 'bg-success';
                                            } elseif ($status == 'Ditolak' || $status == 'Gagal') {
                                                $badge_class = 'bg-danger';
                                            } elseif (str_contains($status, 'Menunggu')) {
                                                $badge_class = 'bg-warning text-dark';
                                            }
                                        ?>
                                        <span class="badge <?= $badge_class; ?>">
                                            <?= htmlspecialchars($status); ?>
                                        </span>
                                    </td>
                                    <td class="text-end fw-semibold">Rp <?= number_format($row['total_bayar'], 0, ',', '.'); ?></td>
                                    
                                    <td class="text-center">
                                        <!-- 
                                            =============================================
                                            INI ADALAH PERBAIKANNYA:
                                            Link di bawah ini mengarah ke file yang benar:
                                            "hapus_laporan_transaksi.php"
                                            =============================================
                                        -->
                                        <a href="hapus_laporan_transaksi.php?id=<?= $row['transaksi_id']; ?>" 
                                           class="btn btn-danger btn-sm" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus transaksi ini? Data pembayaran dan laporan terkait juga akan terhapus.');">
                                            <i class="bi bi-trash-fill"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted p-5">
                                    <h5 class="mb-0">Belum ada transaksi.</h5>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
        duration: 600,
        once: true
    });
</script>

</body>
</html>