<?php
session_start();
include 'config/koneksi.php';

// Query paket tetap ada jika nanti dibutuhkan, tapi tampilan kita buat statis dulu sesuai request
$query_paket = "SELECT * FROM paket_bimbel ORDER BY harga ASC";
$result_paket = mysqli_query($koneksi, $query_paket);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bimbel UTBK - Siap Tembus PTN!</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="style.css">
    
    <!-- BARU: Link CSS untuk Animasi AOS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <!-- Tambahan CSS untuk smooth scroll -->
    <style>
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top navbar-home">
        <div class="container py-2">
            <a class="navbar-brand fw-bold text-primary" href="user_home.php">
                Bimbel<span class="text-accent">UTBK</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#benefits">Manfaat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#paket">Paket</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimoni">Testimoni</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#faq">FAQ</a>
                    </li>
                    <!-- Link "Tentang Kami" di Navbar -->
                    <li class="nav-item">
                        <a class="nav-link" href="#tentang-kami">Tentang Kami</a>
                    </li>
                </ul>
                <div class="ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="dropdown">
                            <a class="btn btn-primary btn-sm dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                Halo, <?= isset($_SESSION['nama_user']) ? htmlspecialchars(explode(' ', $_SESSION['nama_user'])[0]) : 'User'; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="user/profil.php">Profil Saya</a></li>
                                <li><a class="dropdown-item" href="transaksi/tampil_transaksi.php">Riwayat Transaksi</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="user/logout.php">Logout</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="user/login.php" class="btn btn-secondary btn-sm me-2">Login</a>
                        <a href="user/daftar.php" class="btn btn-accent btn-sm">Daftar</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <section id="home" class="hero-new-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6" data-aos="fade-right">
                    <h1 class="display-4 fw-bold">Raih Impian dengan Selamat Belajar</h1>
                    <p class="lead my-4">Belajar dari para ahli, dapatkan sertifikat, dan raih karir impian Anda.</p>
                    <a href="#paket" class="btn btn-accent btn-lg">Lihat Paket</a>
                    
                    <!-- Link "Tentang Kami" di Hero -->
                    <a href="#tentang-kami" class="btn btn-outline-light btn-lg ms-2">Tentang Kami</a>
                    
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <img src="../bimbel_utbk/images/logo2.png" class="img-fluid rounded-3 shadow-lg" alt="Hero Image">
                </div>
            </div>
        </div>
    </section>

    <section id="benefits" class="benefits-section py-5">
        <div class="container">
            <h2 class="text-center fw-bold mb-5" data-aos="fade-up">Keuntungan Belajar di Sini</h2>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="benefit-item">
                        <span class="benefit-number">01</span>
                        <h4 class="fw-bold">Capai Target Belajarmu</h4>
                        <p>Raih hasil terbaik dari setiap paket yang kamu selesaikan.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="benefit-item">
                        <span class="benefit-number">02</span>
                        <h4 class="fw-bold">Tutor Berpengalaman</h4>
                        <p>Belajar langsung dari para ahli di bidangnya.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="benefit-item">
                        <span class="benefit-number">03</span>
                        <h4 class="fw-bold">Akses Selamanya</h4>
                        <p>Nikmati akses video dan modul pembelajaran tanpa batas waktu, meski masa langganan berakhir.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="benefit-item">
                        <span class="benefit-number">04</span>
                        <h4 class="fw-bold">Tryout Realistis</h4>
                        <p>Soal tryout dengan standar terbaru (IRTP) dan pembahasan.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="benefit-item">
                        <span class="benefit-number">05</span>
                        <h4 class="fw-bold">Konsultasi Langsung</h4>
                        <p>Pertemuan online dengan pembimbing dan tanyakan langsung materinya</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="benefit-item">
                        <span class="benefit-number">06</span>
                        <h4 class="fw-bold">Materi Fleksibel</h4>
                        <p>Belajar sesuai kecepatan Anda sendiri, kapan saja.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="paket" class="paket-section-new py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="fw-bold">Pilih Paket Bimbel Kamu</h2>
                <p class="text-muted">Belajar lebih mudah dan efektif sesuai kebutuhanmu ✨</p>
            </div>
            
            <div class="row g-4 justify-content-center">
                
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card h-100 border-0 shadow-sm" style="background: linear-gradient(to bottom right, #4facfe 0%, #00f2fe 100%);">
                        <div class="card-body p-4 text-white d-flex flex-column">
                            <div class="text-center mb-4">
                                <h4 class="fw-bold">Paket Basic</h4>
                                <h2 class="fw-bold my-3">Rp. 500.000</h2>
                            </div>
                            <ul class="list-unstyled flex-grow-1 mb-4">
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 3 Video Pembelajaran (7 menit)</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 5 Pelatihan Soal</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 2 Buku Pembelajaran</li>
                            </ul>
                            <a href="pembayaran/tambah_pembayaran.php?paket_id=PK001" class="btn btn-light text-primary fw-bold w-100">Pilih Paket</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card h-100 border-0 shadow-sm" style="background: linear-gradient(to bottom right, #fba834 0%, #f8d800 100%);">
                        <div class="card-body p-4 text-white d-flex flex-column">
                            <div class="text-center mb-4">
                                <h4 class="fw-bold">Paket Standart</h4>
                                <h2 class="fw-bold my-3">Rp. 800.000</h2>
                            </div>
                            <ul class="list-unstyled flex-grow-1 mb-4">
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 6 Video Pembelajaran (12 menit)</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 12 Pelatihan Soal</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 4 Buku Pembelajaran</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 1 Pertemuan Dengan Pembimbing</li>
                            </ul>
                            <a href="pembayaran/tambah_pembayaran.php?paket_id=PK002" class="btn btn-light text-warning fw-bold w-100">Pilih Paket</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="card h-100 border-0 shadow-sm" style="background: linear-gradient(to bottom right, #7f00ff 0%, #e100ff 100%);">
                        <div class="card-body p-4 text-white d-flex flex-column">
                            <div class="text-center mb-4">
                                <h4 class="fw-bold">Paket Premium</h4>
                                <h2 class="fw-bold my-3">Rp. 1.200.000</h2>
                            </div>
                            <ul class="list-unstyled flex-grow-1 mb-4">
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 15 Video Pembelajaran (18 menit)</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 25 Pelatihan Soal</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 12 Buku Pembelajaran</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> 5 Pertemuan Dengan Pembimbing</li>
                                <li class="mb-2"><i class="bi bi-check2 me-2"></i> Bonus Sertifikat Resmi Bimbel</li>
                            </ul>
                            <a href="pembayaran/tambah_pembayaran.php?paket_id=PK003" class="btn btn-light text-purple fw-bold w-100" style="color: #7f00ff;">Pilih Paket</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section id="testimoni" class="testimonial-section-new py-5">
        <div class="container">
            <h2 class="text-center fw-bold mb-5" data-aos="fade-up">Apa Kata Mereka?</h2>
            <div class="row g-4">
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="testimonial-card-new">
                        <p>"Materi sangat lengkap dan mudah dipahami. Tryout-nya juga sangat membantu saya lolos UTBK!"</p>
                        <div class="d-flex align-items-center mt-3">
                            <img src="https://placehold.co/50x50/333/FFF?text=A" class="rounded-circle" alt="User">
                            <div class="ms-3">
                                <h6 class="fw-bold mb-0">Ahmad B.</h6>
                                <span class="text-muted">Lolos di UI</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="testimonial-card-new">
                        <p>"Tutornya sabar dan cara menjelaskannya asik. Saya jadi lebih percaya diri menghadapi soal-soal sulit."</p>
                        <div class="d-flex align-items-center mt-3">
                            <img src="https://placehold.co/50x50/333/FFF?text=C" class="rounded-circle" alt="User">
                            <div class="ms-3">
                                <h6 class="fw-bold mb-0">Citra L.</h6>
                                <span class="text-muted">Lolos di UGM</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="testimonial-card-new">
                        <p>"Modul akses selamanya sangat berguna. Saya bisa mengulang materi kapanpun saya butuh."</p>
                        <div class="d-flex align-items-center mt-3">
                            <img src="https://placehold.co/50x50/333/FFF?text=B" class="rounded-circle" alt="User">
                            <div class="ms-3">
                                <h6 class="fw-bold mb-0">Bayu P.</h6>
                                <span class="text-muted">Lolos di ITB</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="faq" class="faq-section py-5 bg-light">
        <div class="container">
            <h2 class="text-center fw-bold mb-5" data-aos="fade-up">Pertanyaan Sering Diajukan (FAQ)</h2>
            <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-8">
                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                                    Bagaimana cara mendaftar?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Anda bisa mendaftar dengan mengklik tombol "Daftar" di pojok kanan atas, mengisi data diri, lalu memilih paket yang diinginkan dan melakukan pembayaran.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                                    Apakah saya akan mendapat sertifikat?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Ya, Anda akan mendapatkan e-sertifikat setelah menyelesaikan seluruh rangkaian materi dan tryout pada paket yang Anda ambil.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
                                    Metode pembayaran apa saja yang diterima?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Kami menerima pembayaran melalui transfer bank (Mandiri, BCA, BNI) dan e-wallet (GoPay, OVO, Dana).
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================= -->
    <!--     BARU: SECTION TENTANG KAMI (di bawah FAQ) -->
    <!-- ============================================= -->
    <section id="tentang-kami" class="py-5">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-6" data-aos="fade-right">
                    <!-- Ganti URL placeholder jika Anda punya gambar tim -->
                    <img src="../bimbel_utbk/images/logobimbelutbk.png" class="img-fluid rounded-3 shadow-lg" alt="Hero Image">
                </div>
                <div class="col-lg-6" data-aos="fade-left" data-aos-delay="100">
                    <h2 class="fw-bold mb-3">Tentang Bimbel UTBK</h2>
                    <p class="text-muted mb-4">
                        Kami adalah platform bimbingan belajar yang didedikasikan untuk membantu siswa-siswi di seluruh Indonesia meraih impian mereka menembus Perguruan Tinggi Negeri (PTN) favorit. 
                        Berdiri sejak 2020, kami telah membantu ribuan siswa mempersiapkan diri menghadapi UTBK dengan materi terstruktur, tryout realistis, dan bimbingan dari tutor berpengalaman.
                    </p>
                    <p class="text-muted">
                        Misi kami adalah menyediakan pendidikan berkualitas yang fleksibel dan terjangkau, sehingga setiap siswa (seperti kamu, Mahasiswa Teknik Informatika!) memiliki kesempatan yang sama untuk sukses.
                    </p>
                    
                </div>
            </div>
        </div>
    </section>

    <!-- PERUBAHAN 2: Menghapus id="tentang-kami" dari footer -->
    <footer class="footer-new bg-dark text-white pt-5 pb-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5 class="fw-bold">Bimbel<span class="text-accent">UTBK</span></h5>
                    <p class="text-muted">Membantu Anda meraih kampus impian melalui bimbingan belajar yang terstruktur dan berkualitas.</p>
                </div>
                <div class="col-md-2">
                    <h6 class="fw-bold">Link</h6>
                    <ul class="list-unstyled">
                        <li><a href="#home" class="footer-link">Home</a></li>
                        <li><a href="#paket" class="footer-link">Paket</a></li>
                        <li><a href="#faq" class="footer-link">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h6 class="fw-bold">Kontak</h6>
                    <ul class="list-unstyled">
                        <li class="text-muted"><i class="bi bi-envelope me-2"></i> bimbelUTBK@co.id</li>
                        <li class="text-muted"><i class="bi bi-whatsapp me-2"></i> +62 812 3456 7890</li>
                        <li class="text-muted"><i class="bi bi-geo-alt me-2"></i> Malang, Indonesia</li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h6 class="fw-bold">Ikuti Kami</h6>
                    <a href="#" class="btn btn-outline-secondary btn-floating me-2"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="btn btn-outline-secondary btn-floating me-2"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="btn btn-outline-secondary btn-floating me-2"><i class="bi bi-instagram"></i></a>
                </div>
            </div>
            <hr class="my-4">
            <p class="text-center text-muted mb-0">&copy; 2025 Bimbel UTBK. All rights reserved.</p>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- BARU: Script untuk Inisialisasi AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800, // Durasi animasi
            once: true // Animasi hanya sekali
        });
    </script>
</body>
</html>